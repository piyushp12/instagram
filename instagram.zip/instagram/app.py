from playwright.sync_api import sync_playwright
import time
import random
from flask import Flask, request, jsonify, render_template, Response
import os
import logging
import csv
import instaloader
import pandas as pd
import io

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class FollowerBot:
    def __init__(self, username, password, account_list):
        self.sp = None
        self.browser = None
        self.cursor = None
        self.username = username
        self.password = password
        self.account_list = account_list
        print(account_list)

    def safe_wait_for_selector(self, selector, timeout=5000):
        try:
            self.cursor.wait_for_selector(selector, timeout=timeout)
            return True
        except Exception as e:
            print(f"Selector '{selector}' not found: {e}")
            return False

    def bot_login(self):
        if self.safe_wait_for_selector('//*[@id="loginForm"]/div/div[1]/div/label/input', timeout=5000):
            self.cursor.query_selector('//*[@id="loginForm"]/div/div[1]/div/label/input').fill(self.username)
            self.cursor.query_selector('//*[@id="loginForm"]/div/div[2]/div/label/input').fill(self.password)
            self.cursor.query_selector('//*[@id="loginForm"]/div/div[2]/div/label/input').press("Enter")
        else:
            print("Login form not found.")
            return False

        # Check if login succeeded
        if self.safe_wait_for_selector('//*[@id="loginForm"]/span/div', timeout=5000):
            return False
        return True

    def post_follow(self, name):
        time.sleep(random.randint(2, 4))
        self.cursor.goto(f'https://www.instagram.com/{name}')
        
        if not self.safe_wait_for_selector('//main/div/header', timeout=5000):
            print(f"Header not found for account: {name}")
            return False

        follow_button_selector = '//main/div/header/section/div[1]/div//*[contains(text(), "Follow") and not (contains(text(), "Following"))]'
        if self.safe_wait_for_selector(follow_button_selector, timeout=2000):
            self.cursor.click(follow_button_selector)
            return True
        else:
            print(f"Follow button not found for account: {name}")
            return False

    def start_bot(self):
        with sync_playwright() as self.sp:
            self.browser = self.sp.chromium.launch(headless=True)
            self.cursor = self.browser.new_page()
            self.cursor.goto("https://www.instagram.com/accounts/login/")
            if self.bot_login():
                print(f"Logged into Instagram as {self.username}")
                for account in self.account_list:
                    if self.post_follow(account):
                        print(f"Following {account}")
                    else:
                        print(f"Failed to follow {account}")
            else:
                print("Login failed.")


@app.route('/api/follow', methods=['POST'])
def start_follow_bot():
    data = request.json
    bot = FollowerBot(data['username'], data['password'], data['account_list'])
    bot.start_bot()
    return jsonify({"status": "Bot started successfully."})


@app.route('/api/clean-usernames', methods=['POST'])
def clean_user_names():
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file provided"}), 400

        file = request.files['file']
        file_content = file.read().decode('utf-8')
        print("file",file)

        usernames = []
        for line in file_content.splitlines():
            if line.startswith("Username:"):
                parts = line.split(",")
                username = parts[0].replace("Username:", "").strip()
                usernames.append(username)

        return jsonify({"cleaned_usernames": usernames})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

 


@app.route('/')
def InstaBOt():
    return render_template('main.html')


@app.route('/privacy-policy')
def PrivacyPolicy():
    return render_template('privacy-policy.html')


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=5000)
